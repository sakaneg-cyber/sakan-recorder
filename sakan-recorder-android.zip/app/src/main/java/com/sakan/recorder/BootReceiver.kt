package com.sakan.recorder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** يشغّل الخدمة تلقائياً بعد إعادة تشغيل الجهاز */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && Config.isConfigured(ctx)) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, UploadService::class.java))
        }
    }
}
