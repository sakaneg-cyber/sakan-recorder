package com.sakan.recorder

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Config.isLoggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }

        statusView = TextView(this).apply { setPadding(0, 24, 0, 24); textSize = 13f }

        val allFilesBtn = Button(this).apply { text = "١) منح صلاحية كل الملفات" }
        val saveBtn = Button(this).apply { text = "٢) تشغيل المزامنة" }
        val scanBtn = Button(this).apply { text = "٣) فحص ورفع الآن" }
        val refreshBtn = Button(this).apply { text = "تحديث الحالة" }
        val logoutBtn = Button(this).apply { text = "تسجيل خروج" }

        allFilesBtn.setOnClickListener { requestAllFiles(); requestRuntimePerms() }

        saveBtn.setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, UploadService::class.java))
            Toast.makeText(this, "المزامنة شغّالة", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        scanBtn.setOnClickListener {
            Toast.makeText(this, "جاري الفحص...", Toast.LENGTH_SHORT).show()
            thread {
                Scanner.scan(applicationContext)
                runOnUiThread { refreshStatus() }
            }
        }

        refreshBtn.setOnClickListener { refreshStatus() }

        logoutBtn.setOnClickListener {
            Config.logout(this)
            startActivity(Intent(this, LoginActivity::class.java)); finish()
        }

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(40, 60, 40, 40)
                addView(TextView(this@MainActivity).apply {
                    text = "Sales Sakan"; textSize = 22f
                })
                addView(TextView(this@MainActivity).apply {
                    text = "مرحباً: " + Config.repName(this@MainActivity)
                    textSize = 16f; setPadding(0, 8, 0, 20)
                })
                addView(allFilesBtn); addView(saveBtn); addView(scanBtn); addView(refreshBtn)
                addView(TextView(this@MainActivity).apply {
                    text = "- الحالة -"; textSize = 15f; setPadding(0, 24, 0, 0)
                })
                addView(statusView)
                addView(logoutBtn)
            })
        })

        // شغّل المزامنة تلقائياً
        ContextCompat.startForegroundService(this, Intent(this, UploadService::class.java))
        refreshStatus()
    }

    private fun refreshStatus() {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.R ||
            Environment.isExternalStorageManager()
        statusView.text = buildString {
            append("الموظف: ").append(Config.repName(this@MainActivity)).append("\n")
            append("صلاحية كل الملفات: ").append(if (granted) "ممنوحة" else "غير ممنوحة").append("\n")
            append("مجلد التسجيلات: ").append(Status.dir).append("\n")
            append("عدد الملفات: ").append(Status.found).append("\n")
            append("عدد المرفوع: ").append(Status.uploaded).append("\n")
            append("آخر نتيجة: ").append(Status.last)
        }
    }

    private fun requestRuntimePerms() {
        val perms = mutableListOf(Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permLauncher.launch(perms.toTypedArray())
    }

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }
}
