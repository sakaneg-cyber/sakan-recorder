package com.sakan.recorder

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Config.isLoggedIn(this)) { goMain(); return }

        val user = EditText(this).apply { hint = "اسم المستخدم" }
        val pass = EditText(this).apply {
            hint = "الباسورد"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val btn = Button(this).apply { text = "تسجيل الدخول" }
        val msg = TextView(this).apply { setPadding(0, 16, 0, 0) }

        btn.setOnClickListener {
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            if (u.isEmpty() || p.isEmpty()) { msg.text = "اكتب اسم المستخدم والباسورد"; return@setOnClickListener }
            msg.text = "جاري الدخول..."
            thread {
                val name = login(u, p)
                runOnUiThread {
                    if (name != null) {
                        Config.save(this, Config.DEFAULT_SERVER, Config.uploadToken(this), u, name, "")
                        goMain()
                    } else msg.text = "بيانات الدخول غير صحيحة"
                }
            }
        }

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@LoginActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(50, 130, 50, 40)
                addView(TextView(this@LoginActivity).apply { text = "Sales Sakan"; textSize = 28f })
                addView(TextView(this@LoginActivity).apply {
                    text = "تسجيل دخول الموظف"; textSize = 15f; setPadding(0, 10, 0, 34)
                })
                addView(user); addView(pass); addView(btn); addView(msg)
            })
        })
    }

    private fun goMain() { startActivity(Intent(this, MainActivity::class.java)); finish() }

    private fun login(u: String, p: String): String? {
        return try {
            val body = JSONObject().put("username", u).put("password", p).toString()
                .toRequestBody("application/json".toMediaTypeOrNull())
            val req = Request.Builder().url(Config.LOGIN_URL).post(body).build()
            OkHttpClient().newCall(req).execute().use { r ->
                if (!r.isSuccessful) return null
                val j = JSONObject(r.body?.string() ?: "{}")
                if (j.optBoolean("ok")) j.optString("name", u) else null
            }
        } catch (e: Exception) { null }
    }
}
