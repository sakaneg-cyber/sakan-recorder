package com.sakan.recorder

import android.content.Context
import android.provider.CallLog
import kotlin.math.abs

data class CallInfo(
    val phoneNumber: String,
    val direction: String,
    val startedAtMs: Long,
    val durationSec: Int
)

/**
 * يطابق ملف التسجيل مع أقرب مكالمة في السجل (بالتوقيت).
 * محصّن ضد أي خطأ — لو فشل يرجّع null والرفع يكمل عادي.
 */
object CallLogHelper {

    fun findCallNear(ctx: Context, fileTimeMs: Long): CallInfo? {
        val cols = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION
        )
        return try {
            // ملاحظة: بعض الأجهزة (سامسونج) بترفض LIMIT في ترتيب الاستعلام،
            // فبنستخدم الترتيب بدون LIMIT ونحدد العدد في الكود.
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI, cols, null, null,
                CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                val numI = c.getColumnIndex(CallLog.Calls.NUMBER)
                val typeI = c.getColumnIndex(CallLog.Calls.TYPE)
                val dateI = c.getColumnIndex(CallLog.Calls.DATE)
                val durI = c.getColumnIndex(CallLog.Calls.DURATION)

                var best: CallInfo? = null
                var bestDiff = Long.MAX_VALUE
                var count = 0
                while (c.moveToNext() && count < 40) {
                    count++
                    val date = c.getLong(dateI)
                    val dur = c.getInt(durI)
                    val diff = abs(date - fileTimeMs)
                    if (diff < bestDiff && diff < (dur * 1000L + 180_000L)) {
                        bestDiff = diff
                        best = CallInfo(
                            phoneNumber = c.getString(numI) ?: "unknown",
                            direction = when (c.getInt(typeI)) {
                                CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                                CallLog.Calls.INCOMING_TYPE -> "incoming"
                                else -> "missed"
                            },
                            startedAtMs = date,
                            durationSec = dur
                        )
                    }
                }
                best
            }
        } catch (e: Exception) {
            null
        }
    }
}
