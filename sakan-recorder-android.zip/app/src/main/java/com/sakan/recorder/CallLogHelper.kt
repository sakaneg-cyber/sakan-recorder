package com.sakan.recorder

import android.content.Context
import android.provider.CallLog
import kotlin.math.abs

/** بيانات المكالمة المستخرجة من سجل المكالمات */
data class CallInfo(
    val phoneNumber: String,
    val direction: String,   // outgoing / incoming / missed
    val startedAtMs: Long,
    val durationSec: Int
)

/**
 * يطابق ملف التسجيل الجديد مع أقرب مكالمة في سجل المكالمات (بالتوقيت)
 * عشان نجيب رقم العميل واتجاه المكالمة والمدة تلقائياً.
 */
object CallLogHelper {

    fun findCallNear(ctx: Context, fileTimeMs: Long): CallInfo? {
        val cols = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION
        )
        return try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI, cols, null, null,
                "${CallLog.Calls.DATE} DESC LIMIT 20"
            )?.use { c ->
                val numI = c.getColumnIndex(CallLog.Calls.NUMBER)
                val typeI = c.getColumnIndex(CallLog.Calls.TYPE)
                val dateI = c.getColumnIndex(CallLog.Calls.DATE)
                val durI = c.getColumnIndex(CallLog.Calls.DURATION)

                var best: CallInfo? = null
                var bestDiff = Long.MAX_VALUE
                while (c.moveToNext()) {
                    val date = c.getLong(dateI)
                    val dur = c.getInt(durI)
                    // نطابق: بداية المكالمة قريبة من وقت إنشاء ملف التسجيل
                    val diff = abs(date - fileTimeMs)
                    // نافذة سماح: خلال مدة المكالمة + دقيقتين
                    if (diff < bestDiff && diff < (dur * 1000L + 120_000L)) {
                        bestDiff = diff
                        best = CallInfo(
                            phoneNumber = c.getString(numI) ?: "unknown",
                            direction = when (c.getInt(typeI)) {
                                CallLog.Calls.OUTGOING_TYPE -> "outgoing"
                                CallLog.Calls.INCOMING_TYPE -> "incoming"
                                else -> "missed"
                            },
                            startedAtMs = date,
                            durationSec = dur
                        )
                    }
                }
                best
            }
        } catch (e: SecurityException) {
            null   // صلاحية READ_CALL_LOG مش متاحة
        }
    }
}
