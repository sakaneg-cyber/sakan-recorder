package com.sakan.recorder

import android.content.Context

/**
 * إعدادات الجهاز — تُضبط مرة واحدة عند التركيب لكل موبايل سيلز.
 * تُحفظ محلياً في الجهاز.
 */
object Config {
    private const val PREFS = "sakan_recorder_prefs"

    // العنوان الافتراضي لباب المنصة — عدّله لسيرفرك
    const val DEFAULT_SERVER = "https://your-server.com/api/calls/upload"

    fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // عنوان الرفع
    fun serverUrl(ctx: Context): String =
        prefs(ctx).getString("server_url", DEFAULT_SERVER) ?: DEFAULT_SERVER

    // توكن الحماية (نفس UPLOAD_TOKEN في السيرفر)
    fun uploadToken(ctx: Context): String =
        prefs(ctx).getString("upload_token", "") ?: ""

    // بيانات السيلز صاحب الجهاز
    fun repId(ctx: Context): String = prefs(ctx).getString("rep_id", "") ?: ""
    fun repName(ctx: Context): String = prefs(ctx).getString("rep_name", "") ?: ""

    // مجلد تسجيلات المكالمات (يُكتشف تلقائياً، أو يُضبط يدوياً)
    fun recordingsDir(ctx: Context): String =
        prefs(ctx).getString("rec_dir", "") ?: ""

    fun save(
        ctx: Context, serverUrl: String, token: String,
        repId: String, repName: String, recDir: String
    ) {
        prefs(ctx).edit()
            .putString("server_url", serverUrl)
            .putString("upload_token", token)
            .putString("rep_id", repId)
            .putString("rep_name", repName)
            .putString("rec_dir", recDir)
            .apply()
    }

    fun isConfigured(ctx: Context): Boolean =
        uploadToken(ctx).isNotEmpty() && repId(ctx).isNotEmpty()

    /** المسارات الشائعة لتسجيلات المكالمات حسب نوع الجهاز */
    val COMMON_DIRS = listOf(
        "/storage/emulated/0/Recordings/Call",              // أندرويد 12+ / بيكسل
        "/storage/emulated/0/Call",                         // سامسونج
        "/storage/emulated/0/Recordings/Call Recordings",   // أوبو / ريلمي
        "/storage/emulated/0/MIUI/sound_recorder/call_rec", // شاومي
        "/storage/emulated/0/Sounds/CallRecord",            // فيفو
        "/storage/emulated/0/CallRecordings",
        "/storage/emulated/0/PhoneRecord"
    )
}
