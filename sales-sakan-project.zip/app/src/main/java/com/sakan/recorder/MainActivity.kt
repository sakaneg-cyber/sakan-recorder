package com.sakan.recorder

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val repId = EditText(this).apply {
            hint = "معرّف السيلز (rep_id) - مثلاً rep1"; setText(Config.repId(this@MainActivity))
        }
        val repName = EditText(this).apply {
            hint = "اسم السيلز"; setText(Config.repName(this@MainActivity))
        }
        val recDir = EditText(this).apply {
            hint = "مجلد التسجيلات (فارغ = اكتشاف تلقائي)"
            setText(Config.recordingsDir(this@MainActivity))
        }

        statusView = TextView(this).apply { setPadding(0, 24, 0, 24); textSize = 13f }

        val allFilesBtn = Button(this).apply { text = "١) منح صلاحية كل الملفات" }
        val saveBtn = Button(this).apply { text = "٢) حفظ وتشغيل" }
        val scanBtn = Button(this).apply { text = "٣) فحص ورفع الآن" }
        val refreshBtn = Button(this).apply { text = "تحديث الحالة" }

        allFilesBtn.setOnClickListener { requestAllFiles(); requestRuntimePerms() }

        saveBtn.setOnClickListener {
            Config.save(this, Config.DEFAULT_SERVER, Config.uploadToken(this),
                repId.text.toString().trim(), repName.text.toString().trim(),
                recDir.text.toString().trim())
            ContextCompat.startForegroundService(this, Intent(this, UploadService::class.java))
            Toast.makeText(this, "تم التشغيل", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        scanBtn.setOnClickListener {
            Config.save(this, Config.DEFAULT_SERVER, Config.uploadToken(this),
                repId.text.toString().trim(), repName.text.toString().trim(),
                recDir.text.toString().trim())
            Toast.makeText(this, "جاري الفحص...", Toast.LENGTH_SHORT).show()
            thread {
                Scanner.scan(applicationContext)
                runOnUiThread { refreshStatus() }
            }
        }

        refreshBtn.setOnClickListener { refreshStatus() }

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(40, 60, 40, 40)
                addView(TextView(this@MainActivity).apply {
                    text = "Sales Sakan - الإعداد"; textSize = 20f
                })
                addView(TextView(this@MainActivity).apply {
                    text = "السيرفر متضبوط تلقائياً - اكتب اسمك ومعرّفك بس"
                    textSize = 12f; setPadding(0, 8, 0, 16)
                })
                addView(repName); addView(repId); addView(recDir)
                addView(allFilesBtn); addView(saveBtn); addView(scanBtn); addView(refreshBtn)
                addView(TextView(this@MainActivity).apply {
                    text = "- الحالة -"; textSize = 15f; setPadding(0, 24, 0, 0)
                })
                addView(statusView)
            })
        })

        refreshStatus()
    }

    private fun refreshStatus() {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.R ||
            Environment.isExternalStorageManager()
        statusView.text = buildString {
            append("صلاحية كل الملفات: ").append(if (granted) "ممنوحة" else "غير ممنوحة").append("\n")
            append("مجلد التسجيلات: ").append(Status.dir).append("\n")
            append("أحدث ملف صوت: ").append(Status.newest).append("\n")
            append("عدد الملفات: ").append(Status.found).append("\n")
            append("عدد المرفوع: ").append(Status.uploaded).append("\n")
            append("آخر نتيجة: ").append(Status.last)
        }
    }

    private fun requestRuntimePerms() {
        val perms = mutableListOf(Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permLauncher.launch(perms.toTypedArray())
    }

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }
}
