package com.sakan.recorder

import android.app.Application

class RecorderApp : Application()
