package com.sakan.recorder

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * شاشة الإعداد — تُستخدم مرة واحدة عند تركيب الأب على جهاز السيلز:
 *  - إدخال عنوان السيرفر + التوكن + اسم/رقم السيلز.
 *  - طلب الصلاحيات.
 *  - تشغيل الخدمة.
 * بعد كده الأب بيشتغل لوحده للأبد — السيلز ميفتحهوش تاني.
 */
class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val server = EditText(this).apply {
            hint = "عنوان السيرفر (https://.../api/calls/upload)"
            setText(Config.serverUrl(this@MainActivity))
        }
        val token = EditText(this).apply {
            hint = "توكن الرفع"; setText(Config.uploadToken(this@MainActivity))
        }
        val repId = EditText(this).apply {
            hint = "معرّف السيلز (rep_id)"; setText(Config.repId(this@MainActivity))
        }
        val repName = EditText(this).apply {
            hint = "اسم السيلز"; setText(Config.repName(this@MainActivity))
        }
        val recDir = EditText(this).apply {
            hint = "مجلد التسجيلات (اتركه فارغاً للاكتشاف التلقائي)"
            setText(Config.recordingsDir(this@MainActivity))
        }
        val status = TextView(this)

        val saveBtn = Button(this).apply { text = "حفظ وتشغيل" }
        val allFilesBtn = Button(this).apply { text = "منح صلاحية «كل الملفات»" }

        saveBtn.setOnClickListener {
            Config.save(this, server.text.toString().trim(), token.text.toString().trim(),
                repId.text.toString().trim(), repName.text.toString().trim(),
                recDir.text.toString().trim())
            requestRuntimePerms()
            ContextCompat.startForegroundService(this, Intent(this, UploadService::class.java))
            status.text = "✅ تم التشغيل — الأب شغّال في الخلفية"
        }

        allFilesBtn.setOnClickListener { requestAllFiles() }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            addView(TextView(this@MainActivity).apply {
                text = "إعداد Sakan Recorder (مرة واحدة)"; textSize = 18f
            })
            addView(server); addView(token); addView(repId); addView(repName); addView(recDir)
            addView(allFilesBtn); addView(saveBtn); addView(status)
        })
    }

    private fun requestRuntimePerms() {
        val perms = mutableListOf(Manifest.permission.READ_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permLauncher.launch(perms.toTypedArray())
    }

    /** صلاحية «كل الملفات» لقراءة فولدر تسجيلات المكالمات (أندرويد 11+) */
    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName")))
        }
    }
}
