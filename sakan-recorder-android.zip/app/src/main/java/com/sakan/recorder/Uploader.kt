package com.sakan.recorder

import android.content.Context
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/** يرفع ملف مكالمة واحد للمنصة عبر multipart POST */
object Uploader {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.MINUTES)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** يرجّع true لو الرفع نجح */
    fun upload(ctx: Context, file: File, info: CallInfo?): Boolean {
        val media = "audio/*".toMediaTypeOrNull()
        val started = info?.startedAtMs?.let {
            java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
                .format(java.util.Date(it))
        } ?: ""

        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("rep_id", Config.repId(ctx))
            .addFormDataPart("rep_name", Config.repName(ctx))
            .addFormDataPart("phone_number", info?.phoneNumber ?: "unknown")
            .addFormDataPart("direction", info?.direction ?: "outgoing")
            .addFormDataPart("started_at", started)
            .addFormDataPart("duration_sec", (info?.durationSec ?: 0).toString())
            .addFormDataPart("audio", file.name, file.asRequestBody(media))
            .build()

        val req = Request.Builder()
            .url(Config.serverUrl(ctx))
            .addHeader("X-Upload-Token", Config.uploadToken(ctx))
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false   // فشل الشبكة — هيتعاد المحاولة لاحقاً
        }
    }
}
