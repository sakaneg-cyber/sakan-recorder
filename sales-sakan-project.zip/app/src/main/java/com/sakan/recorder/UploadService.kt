package com.sakan.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.FileObserver
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class UploadService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var observer: FileObserver? = null
    private val CH = "sakan_recorder"
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) { running = true; startLoop() }
        Scanner.resolveDir(this)?.let { watch(it) }
        return START_STICKY
    }

    private fun startLoop() {
        scope.launch {
            while (running) {
                try { Scanner.scan(this@UploadService) } catch (e: Exception) { Status.last = "khata: " + e.message }
                Thread.sleep(30_000)
            }
        }
    }

    private fun watch(dir: File) {
        observer?.stopWatching()
        observer = object : FileObserver(dir.absolutePath, CLOSE_WRITE or MOVED_TO) {
            override fun onEvent(event: Int, path: String?) {
                path ?: return
                scope.launch { Thread.sleep(3000); Scanner.scan(this@UploadService) }
            }
        }.also { try { it.startWatching() } catch (e: Exception) {} }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH, "Sales Sakan", NotificationManager.IMPORTANCE_MIN)
            )
        }
        return Notification.Builder(this, CH)
            .setContentTitle("Sales Sakan")
            .setContentText("مزامنة المكالمات نشطة")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { running = false; observer?.stopWatching(); super.onDestroy() }
}

object Scanner {

    private val SKIP = setOf("android", "dcim", "pictures", "movies", "music",
        "download", "downloads", "whatsapp", "telegram", ".thumbnails", "documents",
        "ringtones", "notifications", "alarms")

    fun File.isAudio(): Boolean {
        val n = name.lowercase()
        return isFile && length() > 0 &&
            (n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".amr") ||
             n.endsWith(".wav") || n.endsWith(".aac") || n.endsWith(".3gp") ||
             n.endsWith(".ogg") || n.endsWith(".opus"))
    }

    fun resolveDir(ctx: Context): File? {
        val configured = Config.recordingsDir(ctx)
        if (configured.isNotEmpty() && File(configured).isDirectory) return File(configured)
        Config.COMMON_DIRS.map { File(it) }.firstOrNull { it.isDirectory }?.let { return it }
        return autoFind()
    }

    /** يدوّر على أحدث ملف صوت في الجهاز كله ويعرض مساره للتشخيص */
    private fun autoFind(): File? {
        val root = File("/storage/emulated/0")
        var best: File? = null
        var bestTime = 0L
        var newestPath = "لا يوجد أي ملف صوت ظاهر"
        fun walk(dir: File, depth: Int) {
            if (depth > 5) return
            val kids = try { dir.listFiles() } catch (e: Exception) { null } ?: return
            for (k in kids) {
                if (k.isDirectory) {
                    if (k.name.lowercase() in SKIP) continue
                    walk(k, depth + 1)
                } else if (k.isAudio() && k.lastModified() > bestTime) {
                    bestTime = k.lastModified(); best = k.parentFile; newestPath = k.absolutePath
                }
            }
        }
        try { walk(root, 0) } catch (e: Exception) {}
        Status.newest = newestPath
        return best
    }

    @Synchronized
    fun scan(ctx: Context) {
        val dir = resolveDir(ctx)
        if (dir == null) { Status.dir = "لم يُعثر على مجلد"; Status.found = 0; return }
        Status.dir = dir.absolutePath
        val files = dir.listFiles()?.filter { it.isAudio() }?.sortedBy { it.lastModified() } ?: emptyList()
        Status.found = files.size
        for (f in files) {
            if (Uploaded.has(ctx, f.name)) continue
            val info = CallLogHelper.findCallNear(ctx, f.lastModified())
            val ok = Uploader.upload(ctx, f, info)
            if (ok) { Uploaded.mark(ctx, f.name); Status.uploaded += 1; Status.last = "تم رفع: " + f.name }
            else { Status.last = "فشل رفع: " + f.name }
        }
        if (files.isEmpty()) Status.last = "المجلد موجود بس مفيش تسجيلات"
    }
}

object Status {
    @Volatile var dir: String = "-"
    @Volatile var newest: String = "-"
    @Volatile var found: Int = 0
    @Volatile var uploaded: Int = 0
    @Volatile var last: String = "لسه مبدأش"
}

object Uploaded {
    private const val P = "sakan_uploaded"
    fun has(ctx: Context, name: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).contains(name)
    fun mark(ctx: Context, name: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean(name, true).apply()
}
