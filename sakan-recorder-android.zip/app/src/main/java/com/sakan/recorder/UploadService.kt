package com.sakan.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.FileObserver
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

/**
 * الخدمة الرئيسية — تشتغل في الخلفية دايماً:
 *  1) تراقب فولدر تسجيلات المكالمات (FileObserver).
 *  2) أول ما يظهر تسجيل جديد → تجيب بياناته من سجل المكالمات → ترفعه للمنصة.
 *  3) تعمل فحص دوري (كل بدء تشغيل) لأي ملفات فاتت (لو النت كان مقطوع).
 * السيلز ميعملش أي حاجة — كله تلقائي وصامت.
 */
class UploadService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var observer: FileObserver? = null
    private val CH = "sakan_recorder"

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dir = resolveDir()
        if (dir != null) {
            scanExisting(dir)      // ارفع أي ملفات فاتت
            watch(dir)             // راقب الجديد
        }
        return START_STICKY        // النظام يعيد تشغيلها لو اتقفلت
    }

    /** يحدد فولدر التسجيلات (المضبوط يدوياً أو أول مسار موجود) */
    private fun resolveDir(): File? {
        val configured = Config.recordingsDir(this)
        if (configured.isNotEmpty() && File(configured).isDirectory) return File(configured)
        return Config.COMMON_DIRS.map { File(it) }.firstOrNull { it.isDirectory }
    }

    private fun watch(dir: File) {
        observer?.stopWatching()
        observer = object : FileObserver(dir.absolutePath, CLOSE_WRITE or MOVED_TO) {
            override fun onEvent(event: Int, path: String?) {
                path ?: return
                val f = File(dir, path)
                if (f.isAudio()) {
                    // انتظار بسيط للتأكد إن الملف اكتمل
                    scope.launch { Thread.sleep(3000); handle(f) }
                }
            }
        }.also { it.startWatching() }
    }

    private fun scanExisting(dir: File) {
        scope.launch {
            dir.listFiles()?.filter { it.isAudio() && !Uploaded.has(this@UploadService, it.name) }
                ?.sortedBy { it.lastModified() }
                ?.forEach { handle(it) }
        }
    }

    private fun handle(f: File) {
        if (Uploaded.has(this, f.name)) return
        val info = CallLogHelper.findCallNear(this, f.lastModified())
        val ok = Uploader.upload(this, f, info)
        if (ok) Uploaded.mark(this, f.name)
    }

    private fun File.isAudio(): Boolean {
        val n = name.lowercase()
        return isFile && length() > 0 &&
            (n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".amr") ||
             n.endsWith(".wav") || n.endsWith(".aac") || n.endsWith(".3gp") ||
             n.endsWith(".ogg"))
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH, "Sakan Recorder", NotificationManager.IMPORTANCE_MIN)
            )
        }
        return Notification.Builder(this, CH)
            .setContentTitle("Sakan")
            .setContentText("مزامنة المكالمات نشطة")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { observer?.stopWatching(); super.onDestroy() }
}

/** تتبّع الملفات المرفوعة عشان ما نرفعش نفس المكالمة مرتين */
object Uploaded {
    private const val P = "sakan_uploaded"
    fun has(ctx: Context, name: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).contains(name)
    fun mark(ctx: Context, name: String) =
        ctx.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean(name, true).apply()
}
